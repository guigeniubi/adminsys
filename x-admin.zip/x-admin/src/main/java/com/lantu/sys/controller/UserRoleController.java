package com.lantu.sys.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author xuange
 * @since 2023-09-05
 */
@Controller
@RequestMapping("/sys/userRole")
public class UserRoleController {

}
