<template>
  <div>生日快乐
    <audio controls ref="audio" class="aud">
    <source src="../../assets/园游会.mp3" />
   </audio>

   <video width="320" height="240" controls>
  <source src="../../assets/yyh.mp4" type="video/mp4">
  <object data="movie.mp4" width="320" height="240">
  </object> 
</video>
                  


  </div>

</template>

<script>

</script>

<style>

</style>