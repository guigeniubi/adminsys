<template>
  <div>功能点一</div>
</template>

<script>
export default {

}
</script>

<style>

</style>